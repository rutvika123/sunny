/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.me.reversenumber;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;


@WebService(serviceName = "ReverseNumberWS")
public class ReverseNumberWS {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "reverseNumber")
    public int reverseNumber(@WebParam(name = "number") int number) {
        int reversed = 0;
    while (number != 0) {
        int digit = number % 10;
        reversed = reversed * 10 + digit;
        number /= 10;
    }
    return reversed;
    }
}
